class Contact {
    constructor(name, email, phone, message) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.message = message;
    }
}

module.exports = Contact;